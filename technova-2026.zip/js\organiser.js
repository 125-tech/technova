// ==========================================================================
// TECHNOVA 2026 - Organiser Dashboard & Admin View
// ==========================================================================

function initOrganiserDashboard() {
  const searchInput = document.getElementById("orgSearchInput");
  const eventFilter = document.getElementById("orgEventFilter");
  const exportBtn = document.getElementById("btnExportCsv");
  const resetBtn = document.getElementById("btnResetDummy");

  // Populate Organiser Event Filter Dropdown
  if (eventFilter) {
    eventFilter.innerHTML = `<option value="all">All Events</option>` +
      INITIAL_EVENTS.map(e => `<option value="${e.id}">${e.name}</option>`).join("");

    eventFilter.addEventListener("change", renderOrganiserTable);
  }

  if (searchInput) {
    searchInput.addEventListener("input", renderOrganiserTable);
  }

  if (exportBtn) {
    exportBtn.addEventListener("click", exportRegistrationsToCSV);
  }

  if (resetBtn) {
    resetBtn.addEventListener("click", resetToDummyRegistrations);
  }

  // Listen to updates from registration form
  window.addEventListener("registrations_updated", () => {
    renderOrganiserTable();
  });

  // Initial render
  renderOrganiserTable();
}

// Render the Organiser Table & Metrics
function renderOrganiserTable() {
  const tableBody = document.getElementById("orgTableBody");
  const totalCountEl = document.getElementById("orgStatTotal");
  const soloCountEl = document.getElementById("orgStatSolo");
  const teamCountEl = document.getElementById("orgStatTeam");
  const topEventEl = document.getElementById("orgStatTopEvent");

  if (!tableBody) return;

  const allRegistrations = getRegistrations();

  // Calculate Metrics
  const total = allRegistrations.length;
  const solo = allRegistrations.filter(r => r.participationType === "Individual").length;
  const team = allRegistrations.filter(r => r.participationType === "Team").length;

  // Calculate Top Event
  const eventCounts = {};
  allRegistrations.forEach(r => {
    eventCounts[r.eventName] = (eventCounts[r.eventName] || 0) + 1;
  });
  let topEventName = "None";
  let maxCount = 0;
  for (const [name, count] of Object.entries(eventCounts)) {
    if (count > maxCount) {
      maxCount = count;
      topEventName = name;
    }
  }

  if (totalCountEl) totalCountEl.innerText = total;
  if (soloCountEl) soloCountEl.innerText = solo;
  if (teamCountEl) teamCountEl.innerText = team;
  if (topEventEl) topEventEl.innerText = topEventName;

  // Filtering & Search
  const searchInput = document.getElementById("orgSearchInput");
  const eventFilter = document.getElementById("orgEventFilter");

  const query = searchInput ? searchInput.value.trim().toLowerCase() : "";
  const selectedEvent = eventFilter ? eventFilter.value : "all";

  const filtered = allRegistrations.filter(r => {
    const matchesEvent = (selectedEvent === "all") || (r.eventId === selectedEvent);
    const matchesQuery = 
      r.id.toLowerCase().includes(query) ||
      r.name.toLowerCase().includes(query) ||
      r.email.toLowerCase().includes(query) ||
      r.phone.includes(query) ||
      r.dept.toLowerCase().includes(query) ||
      r.teamName.toLowerCase().includes(query);

    return matchesEvent && matchesQuery;
  });

  if (filtered.length === 0) {
    tableBody.innerHTML = `
      <tr>
        <td colspan="9" style="text-align: center; padding: 30px; color: var(--text-muted);">
          No registrations match the selected filters.
        </td>
      </tr>
    `;
    return;
  }

  tableBody.innerHTML = filtered.map(r => `
    <tr>
      <td class="reg-id-cell">${r.id}</td>
      <td>
        <strong style="color: #fff;">${r.name}</strong>
        <div style="font-size: 0.75rem; color: var(--text-dim);">${r.email}</div>
      </td>
      <td>${r.phone}</td>
      <td>${r.dept} (${r.year})</td>
      <td>
        <span style="font-weight: 600; color: #fff;">${r.eventName}</span>
      </td>
      <td>
        <span style="padding: 3px 8px; border-radius: var(--radius-full); font-size: 0.75rem; background: ${r.participationType === 'Team' ? 'rgba(157,78,221,0.2)' : 'rgba(0,242,254,0.15)'}; color: ${r.participationType === 'Team' ? '#c084fc' : 'var(--accent-cyan)'}; font-weight: 600;">
          ${r.participationType}
        </span>
      </td>
      <td>
        ${r.participationType === 'Team' ? `<strong>${r.teamName}</strong> (${r.teamSize})` : `<span style="color: var(--text-dim);">-</span>`}
      </td>
      <td style="font-size: 0.8rem; color: var(--text-muted); white-space: nowrap;">
        ${new Date(r.timestamp).toLocaleDateString()}
      </td>
      <td>
        <button class="btn-delete-row" onclick="deleteRegistration('${r.id}')" title="Delete record">
          🗑️
        </button>
      </td>
    </tr>
  `).join("");
}

// Delete Record
function deleteRegistration(regId) {
  if (!confirm(`Are you sure you want to delete registration ${regId}?`)) {
    return;
  }

  let regs = getRegistrations();
  regs = regs.filter(r => r.id !== regId);
  saveRegistrations(regs);
  renderOrganiserTable();
  showToast(`Registration ${regId} deleted.`, "error");
}

// Reset Dummy Data
function resetToDummyRegistrations() {
  if (confirm("Reset organiser records to initial sample dummy registrations?")) {
    localStorage.setItem(STORAGE_KEY_REGISTRATIONS, JSON.stringify(INITIAL_REGISTRATIONS));
    renderOrganiserTable();
    showToast("Records reset to sample dummy data.", "success");
  }
}

// Export to CSV Functionality
function exportRegistrationsToCSV() {
  const regs = getRegistrations();
  if (regs.length === 0) {
    showToast("No records available to export.", "error");
    return;
  }

  const headers = [
    "Registration ID",
    "Candidate Name",
    "College Email",
    "Phone Number",
    "Department",
    "Year",
    "Event ID",
    "Event Name",
    "Participation Type",
    "Team Name",
    "Team Size",
    "Team Members",
    "Registration Timestamp"
  ];

  const escapeCSV = (val) => {
    if (val === null || val === undefined) return '""';
    const stringVal = String(val).replace(/"/g, '""');
    return `"${stringVal}"`;
  };

  const rows = regs.map(r => [
    escapeCSV(r.id),
    escapeCSV(r.name),
    escapeCSV(r.email),
    escapeCSV(r.phone),
    escapeCSV(r.dept),
    escapeCSV(r.year),
    escapeCSV(r.eventId),
    escapeCSV(r.eventName),
    escapeCSV(r.participationType),
    escapeCSV(r.teamName),
    escapeCSV(r.teamSize),
    escapeCSV((r.members || []).join("; ")),
    escapeCSV(r.timestamp)
  ].join(","));

  const csvContent = "\uFEFF" + [headers.join(","), ...rows].join("\r\n");

  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  const dateStr = new Date().toISOString().split("T")[0];
  
  link.setAttribute("href", url);
  link.setAttribute("download", `technova_2026_registrations_${dateStr}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  showToast("CSV export downloaded successfully!", "success");
}

// Initialize on DOM load
document.addEventListener("DOMContentLoaded", () => {
  initOrganiserDashboard();
});
