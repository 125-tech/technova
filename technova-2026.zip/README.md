# TECHNOVA 2026 & Electronics Club Recruitment Website

A responsive, high-performance web application designed for the **Electronics Club Technical Recruitment Task**.

---

## 📁 Project Directory Location
Your project files are stored locally at:
```
C:\Users\yashi soni\.gemini\antigravity\scratch\technova-2026\
```

### File Structure:
- 📄 [index.html](file:///C:/Users/yashi%20soni/.gemini/antigravity/scratch/technova-2026/index.html) — **Task 1: TECHNOVA 2026 Fest Website**
- 📄 [apply.html](file:///C:/Users/yashi%20soni/.gemini/antigravity/scratch/technova-2026/apply.html) — **Task 2: Multi-Step Club Recruitment Form**
- 🎨 [css/style.css](file:///C:/Users/yashi%20soni/.gemini/antigravity/scratch/technova-2026/css/style.css) — Modern dark-tech aesthetics, responsive layout, glassmorphic UI
- ⚙️ [js/data.js](file:///C:/Users/yashi%20soni/.gemini/antigravity/scratch/technova-2026/js/data.js) — Event specifications, sample registrations, schedule & FAQs
- ⚙️ [js/main.js](file:///C:/Users/yashi%20soni/.gemini/antigravity/scratch/technova-2026/js/main.js) — Live countdown, dynamic events, validation, duplicate prevention & pass lookup
- ⚙️ [js/organiser.js](file:///C:/Users/yashi%20soni/.gemini/antigravity/scratch/technova-2026/js/organiser.js) — Organiser admin dashboard, search, event filters, metrics & CSV export
- ⚙️ [js/apply.js](file:///C:/Users/yashi%20soni/.gemini/antigravity/scratch/technova-2026/js/apply.js) — Multi-step state, progress bar, draft save/restore, review screen & JSON export

---

## 🚀 How to Open and View the Website

### Method 1: Instant Browser Launch (No Installation Required!)
1. Open **File Explorer** on your computer.
2. Paste this path into the address bar:
   ```
   C:\Users\yashi soni\.gemini\antigravity\scratch\technova-2026
   ```
3. Double-click **`index.html`** to open it directly in Chrome, Edge, or Brave.
4. Double-click **`apply.html`** to test the Multi-Step Application Form.

---

## 🎯 Completed Requirements Checklist

### Task 1: TECHNOVA 2026 Event Website
- [x] **Home Page:** Fest branding, tagline, date, venue, live 4-digit countdown timer, and prominent Register button.
- [x] **Events Section:** 5 featured arenas (Robo Wars, Circuitrix, Code Clash, Tech Quiz, Drone Rush) with rules modal, team limits, and deadlines.
- [x] **Registration Form:** Real-time field validation, dynamic team member roster (2–4 members), duplicate registration prevention by email & event, unique ID generation (`TN26-XXX-XXXX`), and printable entry pass.
- [x] **My Registrations:** Lookup entry passes anytime using registered college email or Registration ID.
- [x] **Organiser View:** Live dashboard with registration count cards, real-time search, filter by event arena, delete action, and **Export to CSV**.
- [x] **Additional Sections:** 3-Day interactive schedule timeline, animated FAQ accordion, and contact details with campus map card.
- [x] **Design:** Fully responsive dark-mode cyber/electronics theme across mobile, tablet, and desktop.

### Task 2: Multi-Step Application Form
- [x] **4 Structured Steps:** Personal Details, Skills & Domains, Experience & Motivation, Review Screen.
- [x] **Progress Bar:** Real-time visual progress percentage and numbered node status.
- [x] **State Retention & Live Validation:** Cannot advance without valid inputs; previous steps retain all data.
- [x] **Review Screen:** Complete summary of entered data with dedicated section edit buttons.
- [x] **Save Draft:** Stores in-progress data in `localStorage` with timestamp and auto-restore banner.
- [x] **Submission Output:** Unique Application Number (`EC-REC-2026-XXXX`), one-click **Download JSON**, and printable application format.

---

## 🎤 Interview Demonstration Guide (For Senior Coordinators)

When demonstrating your project to the club seniors:
1. **Explain the Architecture:**
   - Mention that you built this using clean, semantic **HTML5, CSS3, and modern Vanilla JavaScript** without bloated dependencies, ensuring lightning-fast load times and zero build setup.
2. **Demonstrate Duplicate Prevention:**
   - Register a dummy participant for *Robo Wars*.
   - Try registering the exact same email for *Robo Wars* again; show how the website warns the user with an alert and cites their existing Registration ID.
3. **Showcase the Organiser Dashboard:**
   - Scroll down to the **Organiser View**.
   - Show how the total counts, solo vs. team metrics, and top event auto-calculate.
   - Click **Export to CSV** to prove that coordinators can download an Excel-ready `.csv` file.
4. **Showcase the Multi-Step Form (Task 2):**
   - Click the top banner to go to `apply.html`.
   - Fill in step 1, click **Save Draft**, refresh the page, and show how the draft is restored.
   - Proceed to step 4, show the **Review & Edit** functionality, submit, and download the `.json` application.
