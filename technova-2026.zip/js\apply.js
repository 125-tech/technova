// ==========================================================================
// Electronics Club - Multi-Step Recruitment Application Form Logic
// Task 2 Implementation
// ==========================================================================

const DRAFT_STORAGE_KEY = "electronics_club_draft_v1";
const SUBMISSIONS_STORAGE_KEY = "electronics_club_submissions_v1";

// State
let currentStep = 1;
const totalSteps = 4;

const formData = {
  // Step 1: Personal
  fullName: "",
  rollNo: "",
  email: "",
  phone: "",
  branch: "",
  year: "",
  cgpa: "",
  
  // Step 2: Skills & Interests
  domain: "",
  skills: [],
  portfolio: "",
  hardwareFamiliarity: [],

  // Step 3: Experience & Motivation
  motivation: "",
  experience: "",
  hoursPerWeek: "",
  leadershipRole: ""
};

// ==========================================
// Initialization & Draft Restoration
// ==========================================
document.addEventListener("DOMContentLoaded", () => {
  checkSavedDraft();
  initFormEventListeners();
  updateStepUI();
});

function checkSavedDraft() {
  const saved = localStorage.getItem(DRAFT_STORAGE_KEY);
  if (!saved) return;

  try {
    const draft = JSON.parse(saved);
    const draftBanner = document.getElementById("draftRestoreBanner");
    const draftTime = document.getElementById("draftTimestamp");

    if (draftBanner && draft.savedAt) {
      if (draftTime) draftTime.innerText = new Date(draft.savedAt).toLocaleString();
      draftBanner.style.display = "flex";
    }
  } catch (e) {
    console.error("Error reading draft", e);
  }
}

function restoreDraft() {
  const saved = localStorage.getItem(DRAFT_STORAGE_KEY);
  if (!saved) return;

  try {
    const draft = JSON.parse(saved);
    Object.assign(formData, draft.data);

    // Populate DOM fields
    document.getElementById("appFullName").value = formData.fullName || "";
    document.getElementById("appRollNo").value = formData.rollNo || "";
    document.getElementById("appEmail").value = formData.email || "";
    document.getElementById("appPhone").value = formData.phone || "";
    document.getElementById("appBranch").value = formData.branch || "";
    document.getElementById("appYear").value = formData.year || "";
    document.getElementById("appCgpa").value = formData.cgpa || "";

    document.getElementById("appDomain").value = formData.domain || "";
    document.getElementById("appPortfolio").value = formData.portfolio || "";

    // Skills checkboxes
    document.querySelectorAll("input[name='skills']").forEach(cb => {
      cb.checked = (formData.skills || []).includes(cb.value);
    });

    // Hardware checkboxes
    document.querySelectorAll("input[name='hardware']").forEach(cb => {
      cb.checked = (formData.hardwareFamiliarity || []).includes(cb.value);
    });

    document.getElementById("appMotivation").value = formData.motivation || "";
    document.getElementById("appExperience").value = formData.experience || "";
    document.getElementById("appHours").value = formData.hoursPerWeek || "";
    document.getElementById("appLeadership").value = formData.leadershipRole || "";

    document.getElementById("draftRestoreBanner").style.display = "none";
    showApplyToast("Draft restored successfully!", "success");
    updateStepUI();
  } catch (e) {
    console.error("Draft restore error", e);
  }
}

function discardDraft() {
  localStorage.removeItem(DRAFT_STORAGE_KEY);
  document.getElementById("draftRestoreBanner").style.display = "none";
  showApplyToast("Draft cleared. Starting fresh.", "info");
}

function saveDraft() {
  readCurrentStepValues();
  const draftPayload = {
    data: formData,
    savedAt: new Date().toISOString()
  };
  localStorage.setItem(DRAFT_STORAGE_KEY, JSON.stringify(draftPayload));
  showApplyToast("Progress saved as draft! You can safely close or refresh.", "success");
}

// ==========================================
// Step Navigation & Validation
// ==========================================
function goToStep(step) {
  if (step > currentStep) {
    // Validate all previous steps up to target step
    for (let s = currentStep; s < step; s++) {
      if (!validateStep(s)) {
        showApplyToast(`Please complete Step ${s} before proceeding.`, "error");
        return;
      }
    }
  }

  readCurrentStepValues();
  currentStep = step;
  if (currentStep === 4) {
    populateReviewScreen();
  }
  updateStepUI();
  window.scrollTo({ top: 100, behavior: "smooth" });
}

function nextStep() {
  readCurrentStepValues();
  if (!validateStep(currentStep)) {
    showApplyToast("Please fix the highlighted errors to proceed.", "error");
    return;
  }

  if (currentStep < totalSteps) {
    currentStep++;
    if (currentStep === 4) {
      populateReviewScreen();
    }
    updateStepUI();
    window.scrollTo({ top: 100, behavior: "smooth" });
  }
}

function prevStep() {
  readCurrentStepValues();
  if (currentStep > 1) {
    currentStep--;
    updateStepUI();
    window.scrollTo({ top: 100, behavior: "smooth" });
  }
}

function updateStepUI() {
  // Update step cards visibility
  for (let s = 1; s <= totalSteps; s++) {
    const card = document.getElementById(`stepCard${s}`);
    if (card) {
      card.style.display = s === currentStep ? "block" : "none";
    }
  }

  // Update progress indicator
  const progressPercent = ((currentStep - 1) / (totalSteps - 1)) * 100;
  const progressBar = document.getElementById("applyProgressBar");
  if (progressBar) {
    progressBar.style.width = `${progressPercent}%`;
  }

  // Update step nodes
  for (let s = 1; s <= totalSteps; s++) {
    const node = document.getElementById(`stepNode${s}`);
    if (!node) continue;

    node.classList.remove("active", "completed");
    if (s === currentStep) {
      node.classList.add("active");
    } else if (s < currentStep) {
      node.classList.add("completed");
    }
  }

  // Buttons control
  const prevBtn = document.getElementById("btnApplyPrev");
  const nextBtn = document.getElementById("btnApplyNext");
  const submitBtn = document.getElementById("btnApplySubmit");

  if (prevBtn) {
    prevBtn.style.display = currentStep > 1 ? "inline-flex" : "none";
  }

  if (nextBtn) {
    nextBtn.style.display = currentStep < 4 ? "inline-flex" : "none";
  }

  if (submitBtn) {
    submitBtn.style.display = currentStep === 4 ? "inline-flex" : "none";
  }
}

// Read form values from DOM into state object
function readCurrentStepValues() {
  // Step 1
  formData.fullName = (document.getElementById("appFullName")?.value || "").trim();
  formData.rollNo = (document.getElementById("appRollNo")?.value || "").trim();
  formData.email = (document.getElementById("appEmail")?.value || "").trim();
  formData.phone = (document.getElementById("appPhone")?.value || "").trim();
  formData.branch = document.getElementById("appBranch")?.value || "";
  formData.year = document.getElementById("appYear")?.value || "";
  formData.cgpa = (document.getElementById("appCgpa")?.value || "").trim();

  // Step 2
  formData.domain = document.getElementById("appDomain")?.value || "";
  formData.portfolio = (document.getElementById("appPortfolio")?.value || "").trim();
  
  formData.skills = [];
  document.querySelectorAll("input[name='skills']:checked").forEach(cb => {
    formData.skills.push(cb.value);
  });

  formData.hardwareFamiliarity = [];
  document.querySelectorAll("input[name='hardware']:checked").forEach(cb => {
    formData.hardwareFamiliarity.push(cb.value);
  });

  // Step 3
  formData.motivation = (document.getElementById("appMotivation")?.value || "").trim();
  formData.experience = (document.getElementById("appExperience")?.value || "").trim();
  formData.hoursPerWeek = document.getElementById("appHours")?.value || "";
  formData.leadershipRole = document.getElementById("appLeadership")?.value || "";
}

// Validation per Step
function validateStep(step) {
  let valid = true;

  if (step === 1) {
    valid = validateAppField("appFullName", val => val.length >= 3, "Name must be at least 3 characters") && valid;
    valid = validateAppField("appRollNo", val => val.length >= 4, "Enter a valid student roll/registration number") && valid;
    valid = validateAppField("appEmail", val => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val), "Enter a valid email address") && valid;
    valid = validateAppField("appPhone", val => /^[0-9]{10}$/.test(val.replace(/[\s-]/g, "")), "Enter a valid 10-digit phone number") && valid;
    valid = validateAppField("appBranch", val => val !== "", "Please select your department") && valid;
    valid = validateAppField("appYear", val => val !== "", "Please select your study year") && valid;
    valid = validateAppField("appCgpa", val => !val || (Number(val) >= 0 && Number(val) <= 10), "CGPA must be between 0 and 10") && valid;
  }

  if (step === 2) {
    valid = validateAppField("appDomain", val => val !== "", "Please select your primary domain of interest") && valid;
    const skillsChecked = document.querySelectorAll("input[name='skills']:checked").length;
    const skillsError = document.getElementById("appSkillsError");
    if (skillsChecked === 0) {
      valid = false;
      if (skillsError) {
        skillsError.innerText = "Please select at least one skill or interest.";
        skillsError.style.display = "block";
      }
    } else {
      if (skillsError) skillsError.style.display = "none";
    }
  }

  if (step === 3) {
    valid = validateAppField("appMotivation", val => val.length >= 30, "Please provide at least 30 characters explaining your motivation") && valid;
    valid = validateAppField("appHours", val => val !== "", "Please select your weekly availability") && valid;
  }

  return valid;
}

function validateAppField(fieldId, ruleFn, errorMsg) {
  const input = document.getElementById(fieldId);
  const errorEl = document.getElementById(`${fieldId}Error`);
  if (!input) return true;

  const val = input.value.trim();
  const isValid = ruleFn(val);

  if (isValid) {
    input.classList.remove("is-invalid");
    input.classList.add("is-valid");
    if (errorEl) errorEl.style.display = "none";
  } else {
    input.classList.remove("is-valid");
    input.classList.add("is-invalid");
    if (errorEl) {
      errorEl.innerText = errorMsg;
      errorEl.style.display = "block";
    }
  }

  return isValid;
}

function initFormEventListeners() {
  // Live input error clearing on type
  const liveInputs = [
    "appFullName", "appRollNo", "appEmail", "appPhone", "appBranch",
    "appYear", "appCgpa", "appDomain", "appMotivation", "appHours"
  ];

  liveInputs.forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener("input", () => {
        el.classList.remove("is-invalid");
        const err = document.getElementById(`${id}Error`);
        if (err) err.style.display = "none";
      });
    }
  });

  // Skills checkbox change
  document.querySelectorAll("input[name='skills']").forEach(cb => {
    cb.addEventListener("change", () => {
      const skillsError = document.getElementById("appSkillsError");
      if (skillsError) skillsError.style.display = "none";
    });
  });

  // Submission Handler
  const mainForm = document.getElementById("multiStepRecruitmentForm");
  if (mainForm) {
    mainForm.addEventListener("submit", handleFormSubmission);
  }
}

// ==========================================
// Step 4: Review Screen Population
// ==========================================
function populateReviewScreen() {
  readCurrentStepValues();
  const container = document.getElementById("reviewContentArea");
  if (!container) return;

  container.innerHTML = `
    <!-- Section 1: Personal Details -->
    <div class="review-section-box">
      <div class="review-section-header">
        <h4>1. Personal Information</h4>
        <button type="button" class="btn-edit-step" onclick="goToStep(1)">✏️ Edit</button>
      </div>
      <div class="review-grid">
        <div><span class="rev-label">Full Name:</span> <strong>${formData.fullName}</strong></div>
        <div><span class="rev-label">Roll Number:</span> <strong>${formData.rollNo}</strong></div>
        <div><span class="rev-label">College Email:</span> <strong>${formData.email}</strong></div>
        <div><span class="rev-label">Contact Phone:</span> <strong>${formData.phone}</strong></div>
        <div><span class="rev-label">Department:</span> <strong>${formData.branch}</strong></div>
        <div><span class="rev-label">Year of Study:</span> <strong>${formData.year}</strong></div>
        <div><span class="rev-label">Current CGPA:</span> <strong>${formData.cgpa || "Not specified"}</strong></div>
      </div>
    </div>

    <!-- Section 2: Skills & Domains -->
    <div class="review-section-box">
      <div class="review-section-header">
        <h4>2. Skills & Domain Interests</h4>
        <button type="button" class="btn-edit-step" onclick="goToStep(2)">✏️ Edit</button>
      </div>
      <div class="review-grid">
        <div style="grid-column: span 2;">
          <span class="rev-label">Primary Domain Choice:</span>
          <strong style="color: var(--accent-cyan);">${formData.domain}</strong>
        </div>
        <div style="grid-column: span 2;">
          <span class="rev-label">Technical Skills:</span>
          <div>${formData.skills.map(s => `<span class="review-tag">${s}</span>`).join(" ")}</div>
        </div>
        <div style="grid-column: span 2;">
          <span class="rev-label">Hardware & Lab Tools:</span>
          <div>${formData.hardwareFamiliarity.length > 0 ? formData.hardwareFamiliarity.map(h => `<span class="review-tag" style="background: rgba(157,78,221,0.2); color: #c084fc;">${h}</span>`).join(" ") : "None indicated"}</div>
        </div>
        <div style="grid-column: span 2;">
          <span class="rev-label">Portfolio / GitHub:</span>
          <span>${formData.portfolio ? `<a href="${formData.portfolio}" target="_blank" style="color: var(--accent-blue); text-decoration: underline;">${formData.portfolio}</a>` : "Not provided"}</span>
        </div>
      </div>
    </div>

    <!-- Section 3: Experience & Motivation -->
    <div class="review-section-box">
      <div class="review-section-header">
        <h4>3. Motivation & Availability</h4>
        <button type="button" class="btn-edit-step" onclick="goToStep(3)">✏️ Edit</button>
      </div>
      <div style="display: flex; flex-direction: column; gap: 12px; font-size: 0.9rem;">
        <div>
          <span class="rev-label">Why do you want to join?</span>
          <p style="color: var(--text-main); margin-top: 4px; white-space: pre-wrap; background: rgba(0,0,0,0.2); padding: 12px; border-radius: 8px;">${formData.motivation}</p>
        </div>
        <div>
          <span class="rev-label">Past Project Experience:</span>
          <p style="color: var(--text-main); margin-top: 4px; white-space: pre-wrap; background: rgba(0,0,0,0.2); padding: 12px; border-radius: 8px;">${formData.experience || "None specified"}</p>
        </div>
        <div style="display: flex; gap: 24px;">
          <div><span class="rev-label">Weekly Availability:</span> <strong>${formData.hoursPerWeek}</strong></div>
          <div><span class="rev-label">Interested in Leadership:</span> <strong>${formData.leadershipRole || "Member"}</strong></div>
        </div>
      </div>
    </div>
  `;
}

// ==========================================
// Final Submission & Output
// ==========================================
let submittedApplicationObject = null;

function handleFormSubmission(e) {
  e.preventDefault();

  // Validate all steps
  if (!validateStep(1) || !validateStep(2) || !validateStep(3)) {
    showApplyToast("Please complete all required fields before submitting.", "error");
    return;
  }

  // Generate Unique Application ID
  const randomCode = Math.floor(1000 + Math.random() * 9000);
  const applicationId = `EC-REC-2026-${randomCode}`;

  submittedApplicationObject = {
    applicationId,
    timestamp: new Date().toISOString(),
    ...formData
  };

  // Save to submissions
  try {
    const existing = JSON.parse(localStorage.getItem(SUBMISSIONS_STORAGE_KEY) || "[]");
    existing.unshift(submittedApplicationObject);
    localStorage.setItem(SUBMISSIONS_STORAGE_KEY, JSON.stringify(existing));
    // Clear draft
    localStorage.removeItem(DRAFT_STORAGE_KEY);
  } catch (err) {
    console.error("Storage save error", err);
  }

  // Display Success View
  displaySubmissionSuccess(submittedApplicationObject);
}

function displaySubmissionSuccess(app) {
  document.getElementById("formContainer").style.display = "none";
  const successContainer = document.getElementById("applySuccessScreen");
  successContainer.style.display = "block";

  document.getElementById("successAppId").innerText = app.applicationId;
  document.getElementById("successApplicantName").innerText = app.fullName;
  document.getElementById("successDomain").innerText = app.domain;
  document.getElementById("successTimestamp").innerText = new Date(app.timestamp).toLocaleString();

  window.scrollTo({ top: 0, behavior: "smooth" });
  showApplyToast("Application submitted successfully!", "success");
}

// Download Application as JSON file
function downloadApplicationJSON() {
  if (!submittedApplicationObject) return;

  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(submittedApplicationObject, null, 2));
  const downloadAnchor = document.createElement("a");
  downloadAnchor.setAttribute("href", dataStr);
  downloadAnchor.setAttribute("download", `application_${submittedApplicationObject.applicationId}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();

  showApplyToast("JSON file downloaded!", "success");
}

// Print Application Page
function printApplicationReceipt() {
  if (!submittedApplicationObject) return;

  const app = submittedApplicationObject;
  const printWin = window.open("", "_blank");

  printWin.document.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Electronics Club Application - ${app.applicationId}</title>
      <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 40px; color: #111; line-height: 1.5; }
        .sheet { max-width: 750px; margin: 0 auto; border: 2px solid #222; padding: 30px; border-radius: 8px; }
        .hdr { display: flex; justify-content: space-between; border-bottom: 2px solid #222; padding-bottom: 16px; margin-bottom: 20px; }
        .logo-title { font-size: 24px; font-weight: 800; }
        .sub-title { font-size: 13px; color: #555; text-transform: uppercase; }
        .badge { font-family: monospace; font-size: 16px; font-weight: bold; background: #eee; padding: 6px 12px; border-radius: 4px; }
        .section-h { font-size: 16px; font-weight: 700; margin-top: 20px; margin-bottom: 10px; border-bottom: 1px solid #ccc; padding-bottom: 4px; }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; font-size: 14px; }
        .tag { display: inline-block; background: #eee; padding: 2px 8px; border-radius: 4px; margin-right: 4px; font-size: 12px; }
        .box { background: #f9f9f9; padding: 12px; border-radius: 6px; border: 1px solid #ddd; margin-top: 6px; font-size: 13px; white-space: pre-wrap; }
        .ftr { margin-top: 30px; border-top: 1px dashed #777; padding-top: 14px; display: flex; justify-content: space-between; font-size: 12px; color: #555; }
      </style>
    </head>
    <body>
      <div class="sheet">
        <div class="hdr">
          <div>
            <div class="logo-title">ELECTRONICS CLUB</div>
            <div class="sub-title">Core Team Recruitment Application 2026</div>
          </div>
          <div>
            <div class="badge">${app.applicationId}</div>
          </div>
        </div>

        <div class="section-h">1. Personal Information</div>
        <div class="grid">
          <div><strong>Candidate Name:</strong> ${app.fullName}</div>
          <div><strong>Student Roll No:</strong> ${app.rollNo}</div>
          <div><strong>College Email:</strong> ${app.email}</div>
          <div><strong>Phone Number:</strong> ${app.phone}</div>
          <div><strong>Branch & Year:</strong> ${app.branch} (${app.year})</div>
          <div><strong>Current CGPA:</strong> ${app.cgpa || "N/A"}</div>
        </div>

        <div class="section-h">2. Domain & Technical Skills</div>
        <div style="font-size: 14px; margin-bottom: 8px;"><strong>Applied Domain:</strong> ${app.domain}</div>
        <div style="font-size: 14px; margin-bottom: 8px;"><strong>Technical Skills:</strong> ${app.skills.map(s => `<span class="tag">${s}</span>`).join(" ")}</div>
        ${app.hardwareFamiliarity.length > 0 ? `<div style="font-size: 14px; margin-bottom: 8px;"><strong>Hardware Tools:</strong> ${app.hardwareFamiliarity.map(h => `<span class="tag">${h}</span>`).join(" ")}</div>` : ""}
        ${app.portfolio ? `<div style="font-size: 14px;"><strong>Portfolio / GitHub:</strong> ${app.portfolio}</div>` : ""}

        <div class="section-h">3. Statement of Purpose & Motivation</div>
        <div class="box">${app.motivation}</div>

        ${app.experience ? `
          <div class="section-h">4. Prior Experience / Projects</div>
          <div class="box">${app.experience}</div>
        ` : ""}

        <div class="grid" style="margin-top: 14px;">
          <div><strong>Weekly Availability:</strong> ${app.hoursPerWeek}</div>
          <div><strong>Leadership Interest:</strong> ${app.leadershipRole}</div>
        </div>

        <div class="ftr">
          <div>STATUS: SUBMITTED (PENDING SHORTLIST)</div>
          <div>TIMESTAMP: ${new Date(app.timestamp).toLocaleString()}</div>
        </div>
      </div>
      <script>
        window.onload = function() { window.print(); }
      </script>
    </body>
    </html>
  `);
  printWin.document.close();
}

// Toast Notification
function showApplyToast(msg, type = "success") {
  const container = document.getElementById("applyToastContainer");
  if (!container) return;

  const t = document.createElement("div");
  t.className = `toast ${type}`;
  t.innerHTML = `<span>${type === "success" ? "✓" : "ℹ️"}</span><span>${msg}</span>`;
  container.appendChild(t);

  setTimeout(() => {
    t.style.opacity = "0";
    t.style.transform = "translateX(50px)";
    t.style.transition = "all 0.3s ease";
    setTimeout(() => t.remove(), 300);
  }, 4000);
}
