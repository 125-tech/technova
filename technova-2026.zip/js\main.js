// ==========================================================================
// TECHNOVA 2026 - Main Application Logic
// ==========================================================================

// Storage Keys
const STORAGE_KEY_REGISTRATIONS = "technova_registrations_v1";

// Initialize Local Storage with default data if empty
function initializeStorage() {
  if (!localStorage.getItem(STORAGE_KEY_REGISTRATIONS)) {
    localStorage.setItem(STORAGE_KEY_REGISTRATIONS, JSON.stringify(INITIAL_REGISTRATIONS));
  }
}

// Get all registrations from localStorage
function getRegistrations() {
  try {
    const data = localStorage.getItem(STORAGE_KEY_REGISTRATIONS);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    console.error("Error reading registrations", e);
    return [];
  }
}

// Save all registrations to localStorage
function saveRegistrations(regs) {
  localStorage.setItem(STORAGE_KEY_REGISTRATIONS, JSON.stringify(regs));
  // Dispatch custom event for organiser view update
  window.dispatchEvent(new Event("registrations_updated"));
}

// Toast Notification
function showToast(message, type = "success") {
  const container = document.getElementById("toastContainer");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <span>${type === "success" ? "✓" : "⚠️"}</span>
    <span>${message}</span>
  `;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateX(50px)";
    toast.style.transition = "all 0.3s ease";
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

// ==========================================
// 1. Live Countdown Timer
// ==========================================
function initCountdown() {
  // Target: March 27, 2026 09:30:00
  const eventDate = new Date("2026-03-27T09:30:00").getTime();

  const daysEl = document.getElementById("timerDays");
  const hoursEl = document.getElementById("timerHours");
  const minsEl = document.getElementById("timerMins");
  const secsEl = document.getElementById("timerSecs");

  if (!daysEl) return;

  function updateTimer() {
    const now = new Date().getTime();
    const distance = eventDate - now;

    if (distance < 0) {
      daysEl.innerText = "00";
      hoursEl.innerText = "00";
      minsEl.innerText = "00";
      secsEl.innerText = "00";
      return;
    }

    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);

    daysEl.innerText = String(days).padStart(2, "0");
    hoursEl.innerText = String(hours).padStart(2, "0");
    minsEl.innerText = String(minutes).padStart(2, "0");
    secsEl.innerText = String(seconds).padStart(2, "0");
  }

  updateTimer();
  setInterval(updateTimer, 1000);
}

// ==========================================
// 2. Events Rendering & Filtering
// ==========================================
function renderEvents(filterCategory = "all") {
  const container = document.getElementById("eventsGrid");
  if (!container) return;

  const filtered = filterCategory === "all" 
    ? INITIAL_EVENTS 
    : INITIAL_EVENTS.filter(e => e.category === filterCategory);

  container.innerHTML = filtered.map(ev => `
    <div class="event-card" data-category="${ev.category}">
      <div class="card-top">
        <div class="event-icon-badge">${ev.image}</div>
        <span class="event-category-pill">${ev.category}</span>
      </div>
      <h3 class="event-name">${ev.name}</h3>
      <div class="event-tagline">${ev.tagline}</div>
      <p class="event-desc">${ev.description}</p>
      
      <div class="event-meta-specs">
        <div class="spec-cell">
          <span class="spec-title">Participation</span>
          <span class="spec-val">${ev.type}</span>
        </div>
        <div class="spec-cell">
          <span class="spec-title">Team Size</span>
          <span class="spec-val">${ev.minTeam === ev.maxTeam ? ev.minTeam : `${ev.minTeam} - ${ev.maxTeam}`} Members</span>
        </div>
        <div class="spec-cell">
          <span class="spec-title">Prize Pool</span>
          <span class="spec-val" style="color: var(--accent-amber);">${ev.prize}</span>
        </div>
        <div class="spec-cell">
          <span class="spec-title">Deadline</span>
          <span class="spec-val">${ev.deadline}</span>
        </div>
      </div>

      <div class="card-actions">
        <button class="btn-card-register" onclick="selectEventForRegistration('${ev.id}')">
          Register Now
        </button>
        <button class="btn-card-details" onclick="openEventModal('${ev.id}')">
          Rules & Details
        </button>
      </div>
    </div>
  `).join("");
}

function initEventFilters() {
  const filterBtns = document.querySelectorAll(".filter-btn");
  filterBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      filterBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      const category = btn.getAttribute("data-filter");
      renderEvents(category);
    });
  });
}

// Event Details Modal
function openEventModal(eventId) {
  const ev = INITIAL_EVENTS.find(e => e.id === eventId);
  if (!ev) return;

  const modal = document.getElementById("eventModal");
  const modalContent = document.getElementById("eventModalBody");

  modalContent.innerHTML = `
    <div style="display: flex; align-items: center; gap: 14px; margin-bottom: 16px;">
      <span style="font-size: 2.2rem;">${ev.image}</span>
      <div>
        <h2 style="font-size: 1.8rem; font-weight: 800; color: #fff;">${ev.name}</h2>
        <span style="color: var(--accent-cyan); font-weight: 500;">${ev.tagline}</span>
      </div>
    </div>

    <p style="color: var(--text-muted); margin-bottom: 20px; line-height: 1.6;">${ev.description}</p>

    <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 18px; margin-bottom: 20px;">
      <h4 style="font-size: 0.95rem; text-transform: uppercase; color: var(--accent-cyan); letter-spacing: 0.08em; margin-bottom: 12px;">Official Event Rules</h4>
      <ul style="padding-left: 20px; color: var(--text-main); font-size: 0.9rem; display: flex; flex-direction: column; gap: 8px;">
        ${ev.rules.map(rule => `<li>${rule}</li>`).join("")}
      </ul>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 24px; font-size: 0.88rem;">
      <div>
        <span style="color: var(--text-dim); display: block; text-transform: uppercase; font-size: 0.75rem;">Date & Venue</span>
        <strong style="color: #fff;">${ev.date}</strong>
        <p style="color: var(--text-muted);">${ev.venue}</p>
      </div>
      <div>
        <span style="color: var(--text-dim); display: block; text-transform: uppercase; font-size: 0.75rem;">Student Coordinators</span>
        <strong style="color: #fff;">${ev.coordinators}</strong>
      </div>
    </div>

    <div style="display: flex; gap: 12px;">
      <button class="btn-card-register" style="flex: 1; padding: 12px;" onclick="closeModal('eventModal'); selectEventForRegistration('${ev.id}')">
        Register for this Event
      </button>
      <button class="btn-card-details" onclick="closeModal('eventModal')">
        Close
      </button>
    </div>
  `;

  modal.classList.add("active");
}

// Close Modal Helper
function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.remove("active");
}

// ==========================================
// 3. Dynamic Registration Form Handling
// ==========================================
function populateEventDropdown() {
  const select = document.getElementById("regEvent");
  if (!select) return;

  select.innerHTML = `<option value="">-- Choose an Event --</option>` +
    INITIAL_EVENTS.map(ev => `<option value="${ev.id}">${ev.name} (${ev.type})</option>`).join("");
}

function selectEventForRegistration(eventId) {
  const select = document.getElementById("regEvent");
  if (select) {
    select.value = eventId;
    handleEventChange(eventId);
  }
  const regSection = document.getElementById("register");
  if (regSection) {
    regSection.scrollIntoView({ behavior: "smooth" });
  }
}

function handleEventChange(eventId) {
  const ev = INITIAL_EVENTS.find(e => e.id === eventId);
  const partTypeSelect = document.getElementById("regPartType");
  const teamBox = document.getElementById("teamDetailsBox");

  if (!ev) {
    if (teamBox) teamBox.classList.add("hidden");
    return;
  }

  // Configure participation type options based on event capability
  if (ev.maxTeam === 1) {
    // Solo only
    partTypeSelect.innerHTML = `<option value="Individual">Individual (Solo)</option>`;
    teamBox.classList.add("hidden");
  } else if (ev.minTeam > 1) {
    // Team only
    partTypeSelect.innerHTML = `<option value="Team">Team (${ev.minTeam} - ${ev.maxTeam} members)</option>`;
    teamBox.classList.remove("hidden");
    updateTeamMemberInputs(ev.minTeam, ev.maxTeam);
  } else {
    // Both allowed
    partTypeSelect.innerHTML = `
      <option value="Individual">Individual (Solo)</option>
      <option value="Team">Team (Up to ${ev.maxTeam} members)</option>
    `;
    if (partTypeSelect.value === "Team") {
      teamBox.classList.remove("hidden");
      updateTeamMemberInputs(ev.minTeam, ev.maxTeam);
    } else {
      teamBox.classList.add("hidden");
    }
  }
}

function updateTeamMemberInputs(minTeam, maxTeam) {
  const container = document.getElementById("teamMembersList");
  if (!container) return;

  // We already have leader as field 1 (Applicant). So we need additional (maxTeam - 1) member inputs
  const neededExtra = Math.max(1, minTeam - 1);
  
  container.innerHTML = "";
  for (let i = 1; i <= neededExtra; i++) {
    addMemberInputRow(i + 1);
  }
}

function addMemberInputRow(memberNum) {
  const container = document.getElementById("teamMembersList");
  if (!container) return;

  const currentCount = container.children.length + 1; // +1 for leader
  const eventId = document.getElementById("regEvent").value;
  const ev = INITIAL_EVENTS.find(e => e.id === eventId);
  const maxAllowed = ev ? ev.maxTeam : 4;

  if (currentCount >= maxAllowed) {
    showToast(`Maximum ${maxAllowed} members allowed for this event.`, "error");
    return;
  }

  const div = document.createElement("div");
  div.className = "member-row";
  div.innerHTML = `
    <input type="text" class="form-input member-name-input" placeholder="Member ${currentCount + 1} Full Name" required>
    <input type="email" class="form-input member-email-input" placeholder="Member ${currentCount + 1} Email" required>
    <button type="button" class="btn-remove-member" onclick="this.parentElement.remove()" title="Remove member">✕</button>
  `;
  container.appendChild(div);
}

// Generate unique registration ID: TN26-[EVENT]-[RANDOM]
function generateRegistrationId(eventCode) {
  const prefix = (eventCode.substring(0, 3)).toUpperCase();
  const randomNum = Math.floor(1000 + Math.random() * 9000);
  return `TN26-${prefix}-${randomNum}`;
}

// Live Validation & Form Submission
function initRegistrationForm() {
  const form = document.getElementById("registrationForm");
  const eventSelect = document.getElementById("regEvent");
  const partTypeSelect = document.getElementById("regPartType");
  const addMemberBtn = document.getElementById("btnAddMember");

  if (eventSelect) {
    eventSelect.addEventListener("change", (e) => handleEventChange(e.target.value));
  }

  if (partTypeSelect) {
    partTypeSelect.addEventListener("change", (e) => {
      const teamBox = document.getElementById("teamDetailsBox");
      const eventId = eventSelect.value;
      const ev = INITIAL_EVENTS.find(item => item.id === eventId);
      if (e.target.value === "Team") {
        teamBox.classList.remove("hidden");
        if (ev) updateTeamMemberInputs(ev.minTeam, ev.maxTeam);
      } else {
        teamBox.classList.add("hidden");
      }
    });
  }

  if (addMemberBtn) {
    addMemberBtn.addEventListener("click", () => addMemberInputRow());
  }

  // Live input validation listeners
  const inputs = form.querySelectorAll(".form-input, .form-select");
  inputs.forEach(input => {
    input.addEventListener("input", () => validateField(input));
    input.addEventListener("blur", () => validateField(input));
  });

  // Submit Handler
  form.addEventListener("submit", function(e) {
    e.preventDefault();

    // Hide any previous duplicate alert
    const dupAlert = document.getElementById("duplicateAlert");
    dupAlert.classList.remove("visible");

    // Check validity of all fields
    let isValid = true;
    inputs.forEach(input => {
      if (!validateField(input)) {
        isValid = false;
      }
    });

    if (!isValid) {
      showToast("Please correct the errors in the form before submitting.", "error");
      return;
    }

    const name = document.getElementById("regName").value.trim();
    const email = document.getElementById("regEmail").value.trim().toLowerCase();
    const phone = document.getElementById("regPhone").value.trim();
    const dept = document.getElementById("regDept").value;
    const year = document.getElementById("regYear").value;
    const eventId = document.getElementById("regEvent").value;
    const partType = document.getElementById("regPartType").value;

    const ev = INITIAL_EVENTS.find(e => e.id === eventId);
    if (!ev) {
      showToast("Please choose a valid event.", "error");
      return;
    }

    // 1. DUPLICATE REGISTRATION PREVENTION
    // Check if the same email is already registered for this specific event
    const currentRegistrations = getRegistrations();
    const duplicate = currentRegistrations.find(
      r => r.email.toLowerCase() === email && r.eventId === eventId
    );

    if (duplicate) {
      dupAlert.innerHTML = `
        <span>⚠️ <strong>Duplicate Registration Detected:</strong> You (${email}) are already registered for <strong>${ev.name}</strong> under ID <strong>${duplicate.id}</strong>.</span>
      `;
      dupAlert.classList.add("visible");
      showToast("You are already registered for this event!", "error");
      dupAlert.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }

    // Gather Team Details if applicable
    let teamName = "Solo";
    let teamMembers = [name];
    let teamSize = 1;

    if (partType === "Team") {
      const teamNameInput = document.getElementById("regTeamName");
      teamName = teamNameInput ? teamNameInput.value.trim() : "Unnamed Team";
      if (!teamName) {
        showToast("Please enter your team name.", "error");
        return;
      }

      const memberNameInputs = document.querySelectorAll(".member-name-input");
      memberNameInputs.forEach(input => {
        if (input.value.trim()) {
          teamMembers.push(input.value.trim());
        }
      });
      teamSize = teamMembers.length;
    }

    // Generate Unique ID & Registration Object
    const regId = generateRegistrationId(ev.id);
    const newRegistration = {
      id: regId,
      name,
      email,
      phone,
      dept,
      year,
      eventId: ev.id,
      eventName: ev.name,
      participationType: partType,
      teamName,
      teamSize,
      members: teamMembers,
      timestamp: new Date().toISOString()
    };

    // Save
    currentRegistrations.unshift(newRegistration);
    saveRegistrations(currentRegistrations);

    // Show Success Modal
    displaySuccessModal(newRegistration);

    // Reset Form
    form.reset();
    document.getElementById("teamDetailsBox").classList.add("hidden");
    inputs.forEach(input => {
      input.classList.remove("is-valid", "is-invalid");
    });
    showToast("Registration completed successfully!", "success");
  });
}

// Field Validator
function validateField(input) {
  const id = input.id;
  const val = input.value.trim();
  const errorEl = document.getElementById(`${id}Error`);
  let valid = true;
  let msg = "";

  if (input.required && !val) {
    valid = false;
    msg = "This field is required.";
  } else if (id === "regName" && val.length < 3) {
    valid = false;
    msg = "Name must be at least 3 characters.";
  } else if (id === "regEmail") {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(val)) {
      valid = false;
      msg = "Please enter a valid email address.";
    }
  } else if (id === "regPhone") {
    const phoneRegex = /^[0-9]{10}$/;
    if (!phoneRegex.test(val.replace(/[\s-]/g, ""))) {
      valid = false;
      msg = "Please enter a valid 10-digit mobile number.";
    }
  }

  if (valid) {
    input.classList.remove("is-invalid");
    input.classList.add("is-valid");
    if (errorEl) {
      errorEl.classList.remove("visible");
      errorEl.innerText = "";
    }
  } else {
    input.classList.remove("is-valid");
    input.classList.add("is-invalid");
    if (errorEl) {
      errorEl.innerText = msg;
      errorEl.classList.add("visible");
    }
  }

  return valid;
}

// Display Registration Success Modal & Pass
function displaySuccessModal(reg) {
  const modal = document.getElementById("successModal");
  const body = document.getElementById("successModalBody");
  if (!modal || !body) return;

  body.innerHTML = `
    <div style="text-align: center; margin-bottom: 24px;">
      <div style="width: 64px; height: 64px; background: rgba(16, 185, 129, 0.15); border: 2px solid var(--accent-emerald); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; font-size: 2rem; color: var(--accent-emerald);">
        ✓
      </div>
      <h2 style="font-size: 1.8rem; font-weight: 800; color: #fff; margin-bottom: 6px;">Registration Confirmed!</h2>
      <p style="color: var(--text-muted); font-size: 0.95rem;">You are officially registered for TECHNOVA 2026. Keep your Registration ID safe.</p>
    </div>

    <div class="ticket-card" id="printablePass" style="margin-bottom: 24px;">
      <div class="ticket-header">
        <div>
          <span class="ticket-id-badge">${reg.id}</span>
          <div class="ticket-event-name" style="margin-top: 8px;">${reg.eventName}</div>
        </div>
        <div style="text-align: right;">
          <span style="font-size: 0.75rem; color: var(--text-dim); text-transform: uppercase;">Type</span>
          <div style="color: #fff; font-weight: 700;">${reg.participationType}</div>
        </div>
      </div>

      <div class="ticket-details-grid">
        <div>
          <span class="spec-title">Primary Participant</span>
          <span class="spec-val">${reg.name}</span>
        </div>
        <div>
          <span class="spec-title">College Email</span>
          <span class="spec-val">${reg.email}</span>
        </div>
        <div>
          <span class="spec-title">Contact Phone</span>
          <span class="spec-val">${reg.phone}</span>
        </div>
        <div>
          <span class="spec-title">Dept & Year</span>
          <span class="spec-val">${reg.dept} • ${reg.year}</span>
        </div>
        <div>
          <span class="spec-title">Team Name</span>
          <span class="spec-val">${reg.teamName}</span>
        </div>
        <div>
          <span class="spec-title">Total Members</span>
          <span class="spec-val">${reg.teamSize} Member(s)</span>
        </div>
      </div>

      ${reg.members && reg.members.length > 1 ? `
        <div style="margin-top: 10px; padding-top: 10px; border-top: 1px dashed var(--border-color); font-size: 0.85rem;">
          <span style="color: var(--text-dim); display: block; margin-bottom: 4px;">Roster Members:</span>
          <div style="color: var(--text-main);">${reg.members.join(", ")}</div>
        </div>
      ` : ""}

      <div class="ticket-footer">
        <span class="ticket-status">● Entry Pass Validated</span>
        <span style="font-size: 0.75rem; color: var(--text-dim); font-family: var(--font-mono);">TIMESTAMP: ${new Date(reg.timestamp).toLocaleDateString()}</span>
      </div>
    </div>

    <div style="display: flex; gap: 12px; flex-wrap: wrap;">
      <button class="btn-card-register" style="flex: 1;" onclick="printRegistrationTicket('${reg.id}')">
        🖨️ Print / Save Pass
      </button>
      <button class="btn-card-details" style="flex: 1;" onclick="closeModal('successModal')">
        Close Window
      </button>
    </div>
  `;

  modal.classList.add("active");
}

// ==========================================
// 4. "My Registrations" Lookup Logic
// ==========================================
function initMyRegistrationsLookup() {
  const form = document.getElementById("myRegSearchForm");
  const queryInput = document.getElementById("myRegQuery");
  const resultsContainer = document.getElementById("myRegResults");

  if (!form || !queryInput || !resultsContainer) return;

  form.addEventListener("submit", function(e) {
    e.preventDefault();
    const query = queryInput.value.trim().toLowerCase();

    if (!query) {
      showToast("Please enter an email or Registration ID.", "error");
      return;
    }

    const regs = getRegistrations();
    const matches = regs.filter(r => 
      r.id.toLowerCase() === query || 
      r.email.toLowerCase() === query
    );

    if (matches.length === 0) {
      resultsContainer.innerHTML = `
        <div style="text-align: center; padding: 40px; background: rgba(255,255,255,0.02); border: 1px dashed var(--border-color); border-radius: var(--radius-md);">
          <div style="font-size: 2.2rem; margin-bottom: 10px;">🔍</div>
          <h3 style="color: #fff; margin-bottom: 6px;">No Registrations Found</h3>
          <p style="color: var(--text-muted); font-size: 0.9rem;">No entries found matching "<strong>${query}</strong>". Double-check your spelling or register now.</p>
        </div>
      `;
      return;
    }

    resultsContainer.innerHTML = matches.map(reg => `
      <div class="ticket-card">
        <div class="ticket-header">
          <div>
            <span class="ticket-id-badge">${reg.id}</span>
            <div class="ticket-event-name" style="margin-top: 8px;">${reg.eventName}</div>
          </div>
          <div style="text-align: right;">
            <span style="font-size: 0.75rem; color: var(--text-dim); text-transform: uppercase;">Type</span>
            <div style="color: #fff; font-weight: 700;">${reg.participationType}</div>
          </div>
        </div>

        <div class="ticket-details-grid">
          <div>
            <span class="spec-title">Participant</span>
            <span class="spec-val">${reg.name}</span>
          </div>
          <div>
            <span class="spec-title">College Email</span>
            <span class="spec-val">${reg.email}</span>
          </div>
          <div>
            <span class="spec-title">Dept & Year</span>
            <span class="spec-val">${reg.dept} • ${reg.year}</span>
          </div>
          <div>
            <span class="spec-title">Team Name</span>
            <span class="spec-val">${reg.teamName}</span>
          </div>
          <div>
            <span class="spec-title">Team Size</span>
            <span class="spec-val">${reg.teamSize} Member(s)</span>
          </div>
          <div>
            <span class="spec-title">Registered On</span>
            <span class="spec-val">${new Date(reg.timestamp).toLocaleDateString()}</span>
          </div>
        </div>

        ${reg.members && reg.members.length > 1 ? `
          <div style="margin-top: 10px; padding-top: 10px; border-top: 1px dashed var(--border-color); font-size: 0.85rem;">
            <span style="color: var(--text-dim); display: block; margin-bottom: 4px;">Members:</span>
            <div style="color: var(--text-main);">${reg.members.join(", ")}</div>
          </div>
        ` : ""}

        <div class="ticket-footer">
          <span class="ticket-status">● Registration Active</span>
          <button class="btn-print-ticket" onclick="printRegistrationTicket('${reg.id}')">
            🖨️ Print Pass
          </button>
        </div>
      </div>
    `).join("");
  });
}

function printRegistrationTicket(regId) {
  const regs = getRegistrations();
  const reg = regs.find(r => r.id === regId);
  if (!reg) return;

  const printWindow = window.open("", "_blank");
  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>TECHNOVA 2026 - Pass - ${reg.id}</title>
      <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 40px; color: #111; }
        .pass-card { border: 2px solid #000; border-radius: 12px; padding: 30px; max-width: 600px; margin: 0 auto; }
        .header { display: flex; justify-content: space-between; border-bottom: 2px dashed #444; padding-bottom: 16px; margin-bottom: 20px; }
        .title { font-size: 24px; font-weight: bold; }
        .badge { font-family: monospace; font-size: 16px; font-weight: bold; background: #eee; padding: 4px 8px; border-radius: 4px; }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px; font-size: 14px; }
        .footer { border-top: 2px dashed #444; padding-top: 16px; display: flex; justify-content: space-between; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="pass-card">
        <div class="header">
          <div>
            <div class="title">TECHNOVA 2026</div>
            <div>Electronics Club Annual Technical Fest</div>
          </div>
          <div>
            <div class="badge">${reg.id}</div>
          </div>
        </div>
        <h3>Event: ${reg.eventName}</h3>
        <div class="grid">
          <div><strong>Candidate Name:</strong><br>${reg.name}</div>
          <div><strong>College Email:</strong><br>${reg.email}</div>
          <div><strong>Phone Number:</strong><br>${reg.phone}</div>
          <div><strong>Department & Year:</strong><br>${reg.dept} (${reg.year})</div>
          <div><strong>Participation:</strong><br>${reg.participationType}</div>
          <div><strong>Team Name:</strong><br>${reg.teamName}</div>
        </div>
        ${reg.members ? `<p><strong>Team Members:</strong> ${reg.members.join(", ")}</p>` : ""}
        <div class="footer">
          <div>STATUS: CONFIRMED ENTRY PASS</div>
          <div>VENUE: Campus East Labs & Auditorium</div>
        </div>
      </div>
      <script>
        window.onload = function() { window.print(); }
      </script>
    </body>
    </html>
  `);
  printWindow.document.close();
}

// ==========================================
// 5. Schedule Tabs
// ==========================================
function initSchedule() {
  const container = document.getElementById("scheduleContent");
  const tabBtns = document.querySelectorAll(".schedule-tab-btn");
  if (!container) return;

  function renderDaySchedule(dayIndex) {
    const dayData = INITIAL_SCHEDULE[dayIndex];
    if (!dayData) return;

    container.innerHTML = `
      <div class="timeline-flow">
        ${dayData.events.map(item => `
          <div class="timeline-item">
            <div class="timeline-dot"></div>
            <div class="timeline-time">${item.time}</div>
            <h4 class="timeline-title">${item.title}</h4>
            <div class="timeline-venue">📍 ${item.venue} &bull; <span style="color: var(--accent-purple);">${item.track}</span></div>
          </div>
        `).join("")}
      </div>
    `;
  }

  tabBtns.forEach((btn, idx) => {
    btn.addEventListener("click", () => {
      tabBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      renderDaySchedule(idx);
    });
  });

  // Default day 1
  renderDaySchedule(0);
}

// ==========================================
// 6. FAQ Accordion
// ==========================================
function initFaq() {
  const container = document.getElementById("faqAccordion");
  if (!container) return;

  container.innerHTML = INITIAL_FAQS.map((faq, idx) => `
    <div class="faq-item ${idx === 0 ? "open" : ""}">
      <button class="faq-question">
        <span>${faq.q}</span>
        <span class="faq-toggle-icon">▼</span>
      </button>
      <div class="faq-answer">
        <p>${faq.a}</p>
      </div>
    </div>
  `).join("");

  const items = container.querySelectorAll(".faq-item");
  items.forEach(item => {
    const btn = item.querySelector(".faq-question");
    btn.addEventListener("click", () => {
      const isOpen = item.classList.contains("open");
      // Close others
      items.forEach(i => i.classList.remove("open"));
      if (!isOpen) {
        item.classList.add("open");
      }
    });
  });
}

// ==========================================
// 7. Contact Form Simulation
// ==========================================
function initContactForm() {
  const form = document.getElementById("contactForm");
  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    showToast("Message sent! Our club coordinators will reply shortly.", "success");
    form.reset();
  });
}

// ==========================================
// 8. Mobile Navigation Toggle
// ==========================================
function initMobileMenu() {
  const btn = document.getElementById("mobileMenuBtn");
  const navLinks = document.getElementById("navLinks");
  if (!btn || !navLinks) return;

  btn.addEventListener("click", () => {
    navLinks.classList.toggle("mobile-open");
  });

  // Close when clicking nav link
  navLinks.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => {
      navLinks.classList.remove("mobile-open");
    });
  });
}

// Document Ready
document.addEventListener("DOMContentLoaded", () => {
  initializeStorage();
  initCountdown();
  renderEvents();
  initEventFilters();
  populateEventDropdown();
  initRegistrationForm();
  initMyRegistrationsLookup();
  initSchedule();
  initFaq();
  initContactForm();
  initMobileMenu();
});
